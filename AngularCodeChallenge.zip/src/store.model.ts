export class Store {
    storeId: number
    storeName: string
    storeLocation: string
}
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MobileService } from './mobile.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'AngularCodeChallenge';
  mobileList: any
  constructor(private service: MobileService,private route:Router) { }
  ngOnInit(): void {
    this.service.getMobiles().subscribe(res => {
      this.mobileList = res
    });
  }
  addmobile()
  {
    this.route.navigate(['mobile']);
  }
  editMobile(id:any)
  {
    this.route.navigate(['editmobile',id])
  }
  deleteMobile(id:any)
  {
    this.service.deleteMobile(id).subscribe(res=>console.log("Deleted!"));
  }
}

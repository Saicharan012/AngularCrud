import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-mobile',
  templateUrl: './add-mobile.component.html',
  styleUrls: ['./add-mobile.component.css']
})
export class AddMobileComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

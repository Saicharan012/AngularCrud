import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {HttpClientModule} from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MobileService } from './mobile.service';
import { MobileComponent } from './mobile/mobile.component';
import { StoreService } from './store.service';
import { StoreComponent } from './store/store.component';
import { AddMobileComponent } from './add-mobile/add-mobile.component';
import { EditMobileComponent } from './edit-mobile/edit-mobile.component';

@NgModule({
  declarations: [
    AppComponent,
    MobileComponent,
    StoreComponent,
    AddMobileComponent,
    EditMobileComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule
  ],
  providers: [StoreService,MobileService],
  bootstrap: [AppComponent]
})
export class AppModule { }

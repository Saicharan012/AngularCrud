import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-mobile',
  templateUrl: './edit-mobile.component.html',
  styleUrls: ['./edit-mobile.component.css']
})
export class EditMobileComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

export class Mobile {
    mobileImeIID:string
    modelName: string
    mobilePrice: number
    storeId: number
}